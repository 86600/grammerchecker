package com.demo.grammerchecker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrammercheckerApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrammercheckerApplication.class, args);
	}

}
