package com.demo.grammerchecker.controller;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
	@RequestMapping("/api/grammar")
	public class GrammarCheckerController {

	    private static final String API_URL = "https://api.openai.com/v1/completions";
	    private static final String API_KEY = "your-api-key-here"; // Replace with your OpenAI API key

	    @PostMapping("/check")
	    public String checkGrammar(@RequestBody String text) {
	        try (CloseableHttpClient client = HttpClients.createDefault()) {
	            HttpPost post = new HttpPost(API_URL);
	            post.setHeader("Content-Type", "application/json");
	            post.setHeader("Authorization", "Bearer " + API_KEY);

	            JSONObject request = new JSONObject();
	            request.put("model", "text-davinci-003");
	            request.put("prompt", "Correct the grammar of the following text:\n" + text);
	            request.put("max_tokens", 100);
	            request.put("temperature", 0.7);

	            StringEntity entity = new StringEntity(request.toString());
	            post.setEntity(entity);

	            try (CloseableHttpResponse response = client.execute(post)) {
	                String responseBody = EntityUtils.toString(response.getEntity());
	                JSONObject responseJson = new JSONObject(responseBody);
	                return responseJson.getJSONArray("choices").getJSONObject(0).getString("text").trim();
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	            return "Error occurred while processing the request.";
	        }
	    }
	}


